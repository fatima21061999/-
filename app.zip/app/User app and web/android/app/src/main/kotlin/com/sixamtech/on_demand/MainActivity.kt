package com.sixamtech.on_demand

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
